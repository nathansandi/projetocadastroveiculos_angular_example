import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-listar-veiculos',
  templateUrl: './listar-veiculos.component.html',
  styleUrls: ['./listar-veiculos.component.css']
})
export class ListarVeiculosComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
