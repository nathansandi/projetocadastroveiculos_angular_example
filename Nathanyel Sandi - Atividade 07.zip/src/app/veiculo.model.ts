export interface Veiculo {
    id: number;
    marca: string;
    modelo: string;
    ano: number;
    quantidade: number;
}
